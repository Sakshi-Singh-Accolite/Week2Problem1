package org.example;

import annotation.MethodDocumentation;

public class ClassB {
    @MethodDocumentation("ClassB Method1")
    public void classBMethod1(){

    }

    @MethodDocumentation("ClassB Method2")
    public void classBMethod2(){

    }
}
