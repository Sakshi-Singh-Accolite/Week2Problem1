package org.example;

import annotation.ClassDocumentation;
import annotation.MethodDocumentation;

@ClassDocumentation("classA")
public class ClassA {
    @MethodDocumentation("ClassA Method1")
    public void classAMethod1(){

    }

    @MethodDocumentation("ClassA Method2")
    public void classAMethod2(){

    }
}
